<h3>Tentang Kami</h3>
<p>
    Kami adalah toko komputer yang menyediakan berbagai produk dan layanan terbaik untuk kebutuhan teknologi Anda. 
    Visi kami adalah memberikan solusi berkualitas tinggi untuk mendukung aktivitas Anda di era digital.
</p>
