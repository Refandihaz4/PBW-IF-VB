<aside>
    <div id="sidebar" class="nav-collapse">
        <!-- sidebar menu start -->
        <ul class="sidebar-menu" id="nav-accordion">
            <!-- Profil pengguna -->
            <h5 class="centered"><?php echo $hasil_profil['nm_member']; ?></h5>

            <!-- Menu beranda -->
            <li class="mt">
                <a href="assets\beranda.php\index.php\produk.php">
                    <i class="fa fa-home"></i>
                    <span>Beranda</span>
                </a>
            </li>

            <!-- Menu utama -->
            <li class="mt">
                <a href="index.php">
                    <i class="fa fa-dashboard"></i>
                    <span>Dashboard</span>
                </a>
            </li>

            <!-- Menu Master -->
            <li class="sub-menu">
                <a href="javascript:;">
                    <i class="fa fa-desktop"></i>
                    <span>Master <i class="fa fa-angle-down"></i></span>
                </a>
                <ul class="sub">
                    <li><a href="index.php?page=pelanggan">Pembeli</a></li>
                    <li><a href="index.php?page=barang">Barang</a></li>
                    <li><a href="index.php?page=kategori">Kategori</a></li>
                    <li><a href="index.php?page=user">Petugas</a></li>
                </ul>
            </li>

            <!-- Menu Transaksi -->
            <li class="sub-menu">
                <a href="javascript:;">
                    <i class="fa fa-desktop"></i>
                    <span>Transaksi <i class="fa fa-angle-down"></i></span>
                </a>
                <ul class="sub">
                    <li><a href="index.php?page=jual">Penjualan</a></li>
                </ul>
            </li>

            <!-- Menu Laporan -->
            <li class="sub-menu">
                <a href="javascript:;">
                    <i class="fa fa-desktop"></i>
                    <span>Laporan <i class="fa fa-angle-down"></i></span>
                </a>
                <ul class="sub">
                    <li><a href="index.php?page=laporan">Laporan Penjualan</a></li>
                </ul>
            </li>

            <!-- Menu Setting -->
            <li class="sub-menu">
                <a href="javascript:;">
                    <i class="fa fa-cog"></i>
                    <span>Setting <i class="fa fa-angle-down"></i></span>
                </a>
                <ul class="sub">
                    <li><a href="index.php?page=pengaturan">Pengaturan Toko</a></li>
                    <!-- Menu Tentang Kami dengan Modal -->
                    <li>
                        <a href="#" data-toggle="modal" data-target="#tentangModal">
                            <i class="fa fa-info-circle"></i>
                            <span>Tentang Kami</span>
                        </a>
                    </li>
                </ul>
            </li>

            <!-- Menu Logout dengan ikon -->
            <li>
                <a onclick="return confirm('Ingin Logout?');" href="logout.php">
                    <i class="fa fa-sign-out"></i>
                    <span>Logout</span>
                </a>
            </li>
        </ul>
        <!-- sidebar menu end -->
    </div>
</aside>

<!-- Modal Pop-Up Tentang Kami -->
<div id="tentangModal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="tentangLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="tentangLabel">Tentang Kami</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <p>
                    Kami adalah perusahaan yang bergerak di bidang teknologi, menyediakan solusi terbaik untuk kebutuhan Anda. 
                    Visi kami adalah menciptakan layanan berkualitas tinggi untuk mendukung inovasi dan efisiensi.
                </p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
            </div>
        </div>
    </div>
</div>